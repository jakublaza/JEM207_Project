# JEM207_Project

Project for class JEM207 Data Processing in Python at IES FSV UK.
